﻿using System;
using Utilities;

namespace ClassLibrary1
{
    public class Search
    {
        public static bool IsExist(string name, string[] arr)
        {
            bool exist = false;
            for (int i = 0; i < arr.Length; i++)
            {
                if (name.ToLower()==arr[i].ToLower())
                {
                    exist = true;
                }
               
            }

            if (exist == false)
            {
                throw new NotFoundException($"{name} tapilmadi");
            }
            return exist;
        }
    }
}
