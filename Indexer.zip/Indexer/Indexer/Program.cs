﻿using ClassLibrary1;
using Indexer.Models;
using System;
using System.Reflection;

namespace Indexer
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Indexer
            string word = "lorem";
            //Console.WriteLine(word[0]);

            Book book1 =new  Book("Cinayet ve Ceza");
           // Console.WriteLine(book1.ToString());

            Library library = new Library(4);
            //library.books[0] = book1;
            //Console.WriteLine(library.books[0]);
            library[0] = book1;
            //Console.WriteLine(library[0]);
            #endregion

            #region Exception 

            //NullReferenceException
            //ArgumentException

            //try
            //{
            //    //int num = Convert.ToInt32(Console.ReadLine());
            //    //int num1 = Convert.ToInt32(Console.ReadLine());
            //    //int result = num / num1;
            //}
            ////catch (DivideByZeroException ex)
            ////{
            ////    Console.WriteLine(ex.Message);
            ////}
            //catch (ArithmeticException ex)
            //{
            //   // Console.WriteLine(ex.Message);
            //}


            //finally
            //{
            //    Console.WriteLine("finnaly ishledi");
            //}
            #endregion

            #region CustomExeption
            string[] names = { "Aslan", "Ehmed", "Nergiz", "Jale" };
            string name = "lorem";
           // Console.WriteLine(Search.IsExist(name, names));
            #endregion
            #region Reflection
            Assembly assembly = Assembly.GetExecutingAssembly();

            foreach (var item in assembly.GetTypes())
            {
                Console.WriteLine($"{item} :");
                Console.BackgroundColor = ConsoleColor.Red;
                foreach (var i in item.GetMembers())
                {
                    Console.BackgroundColor = ConsoleColor.Green;
                    Console.WriteLine(i);
                }
            }
            #endregion
        }
    }
}
