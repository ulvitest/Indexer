﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Indexer.Models
{
    class Book
    {
        public string Name { get; set; }
        public int Price { get; set; }

        public Book(string name)
        {
            Name = name;
        }
        public override string ToString()
        {
            return Name; 
        }
    }
}
