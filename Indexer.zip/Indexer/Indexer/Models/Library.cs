﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Indexer.Models
{
    class Library
    {
        private Book[] books;

        public Library(int length)
        {
            books = new Book[length];
        }

        public Book this[int index]
        {
            get
            {
                if (index<=books.Length)
                {
                    return books[index];
                }
                throw new Exception();
            }
            set
            {
                if (index <= books.Length)
                {
                    books[index] = value;
                    return;
                }
                throw new Exception();
            }
        }

        
    }
}
